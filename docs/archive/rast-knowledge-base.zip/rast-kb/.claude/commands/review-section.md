# /review-section
Bir bölümü "Bitti" tanımına göre denetle.

Adımlar:
1. `docs/sections/$ARGUMENTS.md` oku.
2. İlgili bileşeni aç, sınıf/selektörleri doğrula.
3. Kontrol et: a11y (alt/kontrast/focus), mobil, reduced-motion, CLS, motion standardı.
4. Bulguları backlog maddesi olarak section dosyasına yaz.

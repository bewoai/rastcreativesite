# /new-section
Yeni bölüm iskeleti üret.

1. `docs/sections/_template.md`'i kopyala → `docs/sections/$ARGUMENTS.md`.
2. Amaç/konum/içerik/motion alanlarını doldur (varsayım yapma, eksikse sor).
3. CLAUDE.md kurallarına uygun bileşen oluştur.

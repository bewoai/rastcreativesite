# Bağlam: İş (Business)

## Hedefler
1. **Birincil:** Müşteri çekmek. Dönüşüm = "Ücretsiz Ön Görüşme" (form + WhatsApp).
2. **İkincil:** Portföy ve prestij — kalite algısı, marka güveni.

## İdeal müşteri (ICP)
Sakarya ve çevre iller. Segmentler:
- Dükkan / KOBİ (perakende, hizmet)
- Firma & fabrika (sanayi, kurumsal tanıtım)
- Hastane / medikal (tanıtım, anma günleri, kurumsal)
- Bireysel müşteri (etkinlik, özel proje)

İhtiyaçlar: video, sosyal medya yönetimi, reklam, baskı.
Karar verici çoğu zaman işletme sahibi veya pazarlama sorumlusu → metin sade,
sonuç odaklı, teknik jargon az.

## Teklifler (hizmet hatları)
- Video Prodüksiyon (reklam/marka filmi, ürün/kurumsal, medikal)
- Kreatif Strateji & Yönetim (içerik, senaryo, sosyal medya)
- Post-Prodüksiyon & Kurgu (kurgu, color grading, motion graphics)
- (Genişleme: sosyal medya yönetimi, reklam yönetimi, baskı)

## Başarı sinyalleri
- Form gönderimi / WhatsApp tıklaması artışı
- Sakarya + ilçe aramalarında görünürlük
- Showreel izlenme + scroll derinliği

## Karar filtresi
Bir özellik/eklenti lead'i artırıyor mu, kaliteyi mi kanıtlıyor? Hayırsa ertele.

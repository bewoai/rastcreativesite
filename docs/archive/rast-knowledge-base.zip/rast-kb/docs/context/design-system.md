# Bağlam: Tasarım Sistemi

> Kaynak gerçeği koddaki token'lar. Burası özet + ilke. Yeni renk/spacing uydurma,
> mevcut değişkeni kullan. (Token dosyasını koddan doğrula ve buraya senkronla.)

## İlkeler
- İki zemin dünyası: `section--paper` (açık, editöryel) ve `section--ink` (koyu, sinematik).
- Vurgu rengi: turuncu (CTA, playhead, eyebrow). Tek vurgu, dağıtma.
- Tipografi: serif başlık (editöryel ağırlık) + sans gövde.
- Boşluk cömert; "tight" varyantlar arka arkaya gelince tekrar hissi yaratıyor — dikkat.

## Bileşen sözlüğü (gözlemlenen sınıflar)
- `vhero / hero` — hero
- `section--paper / section--ink`, `section--default / --tight`
- `story / story__*` — showreel/parallax (bkz. ilgili section + motion dosyası)
- `marquee / marquee__track` — kayan şerit
- `clapper` — klaket grafiği

## Erişilebilirlik
- Kontrast AA. Koyu zeminde turuncu metinde kontrastı doğrula.
- Odak (focus) görünür olmalı. Klavyeyle gezilebilirlik.
- `prefers-reduced-motion`: animasyonlar kapanmalı (kısmen var, doğrula).

## Yapılacak senkron
- [ ] Gerçek token tablosunu (renk/space/type/radius) koddan çıkar, buraya yapıştır.

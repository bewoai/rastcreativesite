# Bağlam: Marka Sesi & Metin

## Ton
Sinematik ama abartısız. Kendinden emin, sıcak, sonuç odaklı. "Biz" dili.
Set/film metaforu kimliğin parçası ("Sahne 01–07", klaket, playhead).

## Türkçe metin kuralları
- Kısa cümle, net fayda. Süslü sıfat yığını yok.
- Teknik terim gerektiğinde Türkçe + parantez (örn. "renk düzenleme (color grading)").
- CTA tutarlı: **"Ücretsiz Ön Görüşme"** (birincil), "Projelerimizi İzleyin" (ikincil).
- Şehir/ilçe adları doğru ve yerel (Sakarya, Serdivan, Adapazarı, Arifiye...).
- Sayılarla güven ver (13+ marka, 32 içerik, 4K) ama şişirme.

## Yapma
- Karar vericiyi yormak: uzun paragraf, jargon.
- Genel ajans klişesi ("360 derece çözüm ortağınız").
- Telifli/markalı içerik üretmek (logo, müzik, karakter).

## Mikro-kopya
- Başlıklar serif (editöryel), gövde sans.
- Buton fiilleri eylem odaklı: "İzleyin", "İncele", "Oku".

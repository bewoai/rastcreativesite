# Bağlam: Teknik Stack & Konvansiyon

## Stack
- **Astro** (dev sunucu port 4321). Çıktı statik/hibrit.
- Parallax/pin bileşeni **Codex** tarafından kuruldu; kodlar repo içinde
  (`data-production-story` / `story__*`). Saf JS scroll-driven görünüyor.

## Önemli not
Geliştirme analizleri **dev sunucuda** yapıldı (script sayısı vb. temsil etmez).
Gerçek performans için **`astro build` + prod preview** üzerinde ölç.

## Konvansiyonlar
- Bileşenler bölüm bazlı; her bölüm `docs/sections/*` ile eşleşir.
- Görsel: lazy (hero/LCP hariç → eager + preload).
- Animasyon: tek rAF döngüsü tercih; `transition: all` kullanma.
- Commit küçük, branch + preview, sonra merge.

## Build & deploy
- [ ] Build komutu: `___` (doldur)
- [ ] Deploy hedefi: `___` (Netlify/Vercel/cPanel? doldur)
- [ ] Preview URL akışı: `___`

## Doldurulacak
- [ ] Klasör yapısı ağacı (src/pages, src/components, src/content...)
- [ ] İçerik koleksiyonları (blog, portföy) şeması

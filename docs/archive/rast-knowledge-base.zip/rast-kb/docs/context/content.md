# Bağlam: İçerik Modeli & Üretim

## İçerik tipleri
- **Portföy / işler:** kategori (Sosyal Medya, Tanıtım, Reklam...), marka, açıklama,
  görsel/video, (varsa) YouTube linki.
- **Blog / günlük:** tarih, başlık, özet, gövde, kapak görseli.
- **Hizmet:** başlık, alt madde listesi, "Hizmeti İncele" linki.

## Kaynaklar
- Showreel/işler videoları **YouTube'da mevcut**. Net showreel videosu henüz yok
  → Faz 1'de kurgulanacak (bkz. showreel section).

## Üretim ritmi (öneri)
- Blog: 2 hafta/1 yazı (niyet odaklı, yerel).
- Portföy: her teslimden sonra 1 kart + (varsa) VideoObject schema.

## Playbook'lar
- Yeni iş ekleme → `docs/playbooks/add-portfolio-item.md`
- Yeni blog → `docs/playbooks/add-blog-post.md`

# Bağlam: SEO (Yerel odaklı)

## Mevcut durum (gözlem)
İyi: tek H1, title + meta description (~139 krk), canonical, OG, **4× JSON-LD**,
lang=tr, viewport, görseller lazy.
Eksik: **96 görselin ~26'sında alt yok**, **~20 görselde width/height yok** (CLS),
LCP görseli muhtemelen lazy (olmamalı).

## Strateji
- **Yerel SEO ekseni:** Sakarya + Serdivan + ilçeler × hizmet (video, drone, tanıtım,
  reklam, sosyal medya). Mevcut ilçe içeriği iyi temel.
- Hizmet × ilçe kırılımıyla landing derinliği (aşırıya kaçmadan).
- Blog: niyet odaklı ("Sakarya'da video çekimi nasıl planlanır" tarzı) — zaten var.

## Schema (JSON-LD)
- LocalBusiness / VideoProductionCompany: NAP, açılış, hizmet alanı (areaServed).
- BreadcrumbList, Article (blog), VideoObject (showreel/işler — güçlü fırsat).
- [ ] VideoObject ekle (thumbnail, uploadDate, duration, contentUrl/embedUrl).

## Teknik SEO checklist
- [ ] Tüm görsellere açıklayıcı `alt` (portföyde marka + iş türü)
- [ ] Görsel `width/height` ya da `aspect-ratio`
- [ ] LCP görseli `eager` + `<link rel=preload>`
- [ ] sitemap.xml + robots.txt doğrula
- [ ] Open Graph görselleri her sayfa için
- [ ] Prod Lighthouse SEO/Best-practices ≥ 95

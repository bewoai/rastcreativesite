# Bağlam: Motion & Parallax Standardı

> Sitedeki tüm scroll-driven hareketin ortak kuralları. Showreel bölümü buna uyar.

## İlkeler
1. **Amaç hizmet eder:** hareket dikkati yönlendirir, gösteriş için değil.
2. **60fps hedefi:** sadece `transform` + `opacity` animasyonu. `top/left/width` animasyonu yok.
3. **GPU'ya al:** `transform: translate3d(...)`, animasyonlu elemana `will-change: transform`
   (animasyon bitince kaldır).
4. **`transition: all` YASAK** → spesifik özellik (`transition: transform .2s ease`).
5. **Scroll'u tek rAF döngüsünden sür**, her scroll event'inde DOM yazma. Küçük lerp ile yumuşat.
6. **`prefers-reduced-motion: reduce`** → pin ve parallax kapanır, içerik dikey dizilir.
7. **Mobil (<768px):** ağır pin/3B'yi devre dışı bırak, sade dizilim göster.

## Pin (sabitleme) yaklaşımı
- Tercih: CSS `position: sticky` ile pin + JS yalnız ilerleme (progress) hesaplar.
- Mevcut durum: JS class state machine (is-before/is-pinned/is-after). Sorun: programatik/
  hash scroll'da "is-after"da takılabiliyor. IntersectionObserver veya sticky'ye geçir.

## Progress hesabı (önerilen iskelet)
```js
// tek rAF, tek okuma, tek yazma
let raf;
const onScroll = () => { if (!raf) raf = requestAnimationFrame(update); };
function update() {
  raf = null;
  const r = section.getBoundingClientRect();
  const total = section.offsetHeight - window.innerHeight;
  const p = clamp((-r.top) / total, 0, 1); // 0..1
  // p'yi katmanlara dağıt: lerp ile yumuşat
  apply(p);
}
```

## Easing & zamanlama
- Giriş kartları: hafif overshoot olmadan, ease-out.
- "Beat"ler: pano → drone → reels → color, her biri net bir p aralığına otursun.

## Kontrol listesi (her animasyon PR'ında)
- [ ] Sadece transform/opacity
- [ ] will-change yönetildi
- [ ] reduced-motion kapanışı
- [ ] mobil degradasyon
- [ ] hızlı scroll'da rubber-band yok

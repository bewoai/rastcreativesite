# Playbook: Yeni portföy/iş ekle

1. Bağlam oku: `docs/sections/secili-isler.md`, `docs/context/content.md`.
2. İçerik koleksiyonuna kayıt ekle (kategori, marka, açıklama, görsel/video, YouTube linki).
3. Görsel: web-optimize (webp/avif), `alt` yaz (marka + iş türü), `width/height` ekle.
4. Video varsa: VideoObject JSON-LD (thumbnail, uploadDate, duration, embedUrl).
5. `astro build` → CLS/LCP kontrol → branch + preview → merge.
6. `docs/sections/secili-isler.md` backlog'unu güncelle.

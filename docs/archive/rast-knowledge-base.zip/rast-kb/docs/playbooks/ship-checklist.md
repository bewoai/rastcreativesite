# Playbook: Yayın (ship) checklist

- [ ] Branch + preview, canlıya doğrudan değil
- [ ] `astro build` hatasız
- [ ] Yeni/değişen görsellerde alt + boyut
- [ ] Mobil (≤390px) ve masaüstü kontrol
- [ ] `prefers-reduced-motion` ile animasyon kapanıyor
- [ ] Prod Lighthouse: Perf/SEO/Best/A11y regresyon yok (LCP, CLS)
- [ ] İlgili `docs/sections/*.md` güncellendi
- [ ] CTA/WhatsApp linkleri çalışıyor

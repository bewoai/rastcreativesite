# Playbook: Yeni blog yazısı ekle

1. Bağlam: `docs/context/content.md`, `docs/context/brand-voice.md`, `seo.md`.
2. Niyet odaklı başlık (yerel + hizmet). Kapak görseli alt+boyutlu.
3. Frontmatter: tarih, başlık, özet, kapak, (slug).
4. Article JSON-LD. İç linkler (ilgili hizmet/ilçe).
5. Build + preview + merge. content.md ritmini işaretle.

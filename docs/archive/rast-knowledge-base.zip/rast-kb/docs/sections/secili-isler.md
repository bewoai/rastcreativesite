# Bölüm: Seçili İşler (Sahne 02)

## Amaç (iş açısından)
Sosyal kanıt: gerçek işlerle kaliteyi göstermek, portföye/projeye yönlendirmek.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--paper #secili-isler`

## İçerik / veri
- 3 kart: kategori + marka + açıklama + 'Projeyi İncele'
- Veri: portföy koleksiyonu (content collection olmalı)

## Tasarım & motion
Kâğıt zemin. Arkada soluk film-klaket parallax bandı.

## Bilinen sorunlar / backlog
- [ ] Kart görsellerinde alt + boyut
- [ ] 'Tümünü gör' sayfası dolu mu
- [ ] VideoObject schema fırsatı

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

# Bölüm: Neden Rast (Sahne 04)

## Amaç (iş açısından)
İtirazları karşılamak: yerinde çekim, tek elden akış, format uyumu.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--ink #neden-rast`

## İçerik / veri
- 3 güven sinyali: Yerinde çekim · Tek elden · Format uyumu

## Tasarım & motion
**Koyu (ink) zemin + parallax stüdyo arka plan görseli.** Motion: motion-parallax.md.

## Bilinen sorunlar / backlog
- [ ] Parallax bg performansı (yalnız transform)
- [ ] Kontrast AA (koyu zemin)

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

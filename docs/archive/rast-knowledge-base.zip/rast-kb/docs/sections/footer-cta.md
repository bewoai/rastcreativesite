# Bölüm: Final CTA + Footer

## Amaç (iş açısından)
Son dönüşüm itkisi + NAP/iletişim/sosyal.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--ink (CTA) + footer`

## İçerik / veri
- CTA: 'Markanızın sinematik yüzünü birlikte çekelim' + Ücretsiz Ön Görüşme
- Footer: NAP (Serdivan, Sakarya · 0543... · studio@rastcreative.com · WhatsApp), site linkleri, KVKK/Telif

## Tasarım & motion
Koyu zemin.

## Bilinen sorunlar / backlog
- [ ] WhatsApp linki tıklanır + takip parametresi
- [ ] NAP schema ile birebir aynı
- [ ] KVKK & Telif sayfaları dolu

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

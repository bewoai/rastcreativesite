# Bölüm: Günlük / Blog (Sahne 07)

## Amaç (iş açısından)
Otorite + SEO: niyet odaklı yazılarla organik trafik ve güven.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--paper--tight #blog`

## İçerik / veri
- Son 3 yazı kartı + 'Tüm yazılar'
- Veri: blog content collection

## Tasarım & motion
Kâğıt zemin.

## Bilinen sorunlar / backlog
- [ ] Article schema  [ ] kapak görseli alt+boyut
- [ ] Yayın ritmi (content.md)

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

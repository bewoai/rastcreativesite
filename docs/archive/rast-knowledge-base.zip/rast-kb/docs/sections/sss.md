# Bölüm: SSS (Sahne 06)

## Amaç (iş açısından)
Son itirazları kapatıp lead'e taşımak.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--paper #sss`

## İçerik / veri
- Süre, ekip, revizyon, sektör, fiyat, başlangıç soruları (accordion)

## Tasarım & motion
Kâğıt zemin, accordion.

## Bilinen sorunlar / backlog
- [ ] Accordion klavye erişimi (aria-expanded)
- [ ] FAQ schema (JSON-LD) ekle

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

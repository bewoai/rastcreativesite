# Bölüm: Hizmetler (Sahne 03)

## Amaç (iş açısından)
Üç ana hizmet hattını net anlatıp detaya/lead'e taşımak.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--paper #hizmetler-ozet`

## İçerik / veri
- 01 Video Prodüksiyon · 02 Kreatif Strateji & Yönetim · 03 Post-Prodüksiyon & Kurgu
- Her kart alt madde + 'Hizmeti İncele'

## Tasarım & motion
Kâğıt zemin.

## Bilinen sorunlar / backlog
- [ ] Hizmet detay sayfaları dolu mu
- [ ] (Genişleme) sosyal medya yönetimi / reklam / baskı hatları

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

# Bölüm: <Ad> (<sahne>)

## Amaç (iş açısından)
Bu bölüm hangi soruyu yanıtlıyor / ziyaretçiyi hangi adıma taşıyor?

## Konum & dosyalar
- Bileşen: `src/components/___`
- Sayfa: `___`
- İlgili sınıflar/selektörler: `___`

## İçerik
- Başlık / eyebrow / gövde / CTA: `___`
- Veri kaynağı (content collection / inline): `___`

## Tasarım & motion
- Zemin: paper/ink. Animasyon: var/yok → `docs/context/motion-parallax.md`

## Bilinen sorunlar / backlog
- [ ] ___

## "Bitti" kontrolleri
- [ ] a11y (alt, kontrast, focus)  [ ] mobil  [ ] reduced-motion  [ ] CLS

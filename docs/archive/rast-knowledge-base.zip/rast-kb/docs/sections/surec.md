# Bölüm: Süreç (Sahne 05)

## Amaç (iş açısından)
Belirsizliği azaltmak: ön görüşmeden teslime 3 adım.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--paper #surec`

## İçerik / veri
- 01 Ücretsiz ön görüşme · 02 Çekim & prodüksiyon · 03 Kurgu & teslim (2–4 hafta)

## Tasarım & motion
Kâğıt zemin.

## Bilinen sorunlar / backlog
- [ ] Teslim süresi SSS ile tutarlı

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

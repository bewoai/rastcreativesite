# Bölüm: Showreel / Üretim Hikayesi (Sahne 01.5)  ⭐ ODAK

## Amaç (iş açısından)
"Tek çekimden dört ayrı pazarlama çıktısı" mesajını sinematik biçimde kanıtlamak ve
ziyaretçiyi *izlemeye* ikna ederek lead niyetini artırmak. Sitenin "vay" anı burası.

## Konum & teknik
- Bölüm: `<section class="story" data-production-story>` (Astro bileşeni, cid `pysa5me5`).
- Sticky/pin: JS class state machine — `is-before / is-pinned / is-after`.
- Yükseklik ~2169px (~2.9 ekran), sticky iç blok ~867px.
- Katmanlar: `story__deck` (pano), `story__drone`, `story__phone` (Reels),
  `story__steps` (01/02/03 senkron), `story__ambient` (turuncu glow), `story__timeline/playhead`.
- Hareket: kartlarda `matrix3d` 3B tilt var. `deck` `transition: transform .08s linear`;
  `drone`/`phone` `transition: all` (kötü).

## Güçlü yanlar
- 3B tilt derinlik veriyor; adım listesi senkronu akıllıca; ambient ışık marka tonunda.

## Bilinen sorunlar (gözlemlenen)
- [ ] **Gerçek video yok.** "Showreel" ama oynayan görüntü yok; sabit set fotoğrafı +
      hareketsiz sahte playhead. → En büyük kayıp.
- [ ] **Kart çakışması:** orta ilerlemede `story__drone` ("DRONE ROTA / Saha + mekan")
      pano başlığı ve "01/04" sayacının üstüne biniyor. z-index/konum düzelt.
- [ ] **"4K BRAND FİLM" etiketi kırpılıyor** → "K BRAND FİLM" görünüyor (overflow/padding).
- [ ] **`transition: all`** drone/phone'da → sadece `transform`.
- [ ] **`will-change` yok**, `translate3d` yok → repaint riski.
- [ ] **`.08s linear` transition** hızlı scroll'da lastik hissi → rAF + lerp.
- [ ] **Pin state machine kırılgan** (programatik scroll'da is-after'da takılıyor).
- [ ] **Bölüm uzun**, içerik payload'ına göre boş hissi; beat'leri sıkılaştır.
- [ ] **Mobil + reduced-motion** doğrulanmadı (6 reduced-motion kuralı var ama pin için test et).

## Faz 1 planı — gerçek showreel
1. YouTube'daki işlerden **20–30 sn** sessiz kurgu çıkar.
2. `ffmpeg` ile web'e uygun **muted, loop, poster'lı** çıktı (mp4 H.264 + webm),
   `automations/transcode-showreel.md`'deki reçete.
3. Panonun (`story__deck` ekranı) içine `<video muted loop playsinline autoplay preload=metadata poster=...>`.
   Veya: poster + tıkla → lightbox/YouTube embed (autoplay'i bütçeye göre seç).
4. Playhead'i videoya bağla (gerçek currentTime/duration) ya da tamamen dekoratif yap.
5. VideoObject JSON-LD ekle (`docs/context/seo.md`).

## Faz 2 planı — akıcılık & bug
- Çakışmayı düzelt (kart konumları + z-index katmanlaması).
- "4K" etiketinin overflow'unu aç / padding ver.
- `transition: all` → `transform`; `will-change: transform`; `translate3d`.
- Scroll'u `motion-parallax.md` rAF iskeletine taşı; sticky'ye geçmeyi değerlendir.
- Katmanlara farklı hız ver (gerçek parallax derinliği).

## "Bitti"
- [ ] Gerçek video oynuyor (mobil dahil)  [ ] Çakışma yok  [ ] 60fps  [ ] reduced-motion kapanıyor
- [ ] VideoObject schema  [ ] Lighthouse CLS/LCP regresyon yok

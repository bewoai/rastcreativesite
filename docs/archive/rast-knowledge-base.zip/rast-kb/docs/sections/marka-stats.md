# Bölüm: Markalar & İstatistik (Sahne 02.5)

## Amaç (iş açısından)
Güven sinyali: çalışılan marka sayısı ve standartlarla güven inşa etmek.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--paper`

## İçerik / veri
- 13+ MARKA · 32 İÇERİK · 4K · Sakarya MERKEZLİ

## Tasarım & motion
Kâğıt zemin, dört sütun.

## Bilinen sorunlar / backlog
- [ ] Sayılar hero ile tutarlı
- [ ] (Opsiyon) gerçek marka logoları bandı

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

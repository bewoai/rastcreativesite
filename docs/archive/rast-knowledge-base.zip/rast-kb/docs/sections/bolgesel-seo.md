# Bölüm: Bölgesel Hizmetler + SEO Metni (Sahne 03.5)

## Amaç (iş açısından)
Yerel SEO ve niyet: ilçe bazlı hizmet + 'nasıl planlanır' içeriğiyle organik yakalamak.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `section--paper--tight`

## İçerik / veri
- Hizmet × ilçe listesi (Sakarya/Serdivan/Adapazarı/Arifiye +18 bölge)
- Uzun SEO metni + CTA

## Tasarım & motion
Kâğıt zemin, arka planda klaket parallax bandı.

## Bilinen sorunlar / backlog
- [ ] İlçe/hizmet landing derinliği
- [ ] Arka arkaya 'tight' bloklarda tekrar hissini azalt

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

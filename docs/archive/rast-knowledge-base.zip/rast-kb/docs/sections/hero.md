# Bölüm: Hero (Sahne 01)

## Amaç (iş açısından)
İlk 5 saniyede ne yaptığımızı ve nerede olduğumuzu söyleyip birincil CTA'ya taşımak.

## Konum & dosyalar
- Bileşen: `src/components/___`  ·  İlgili sınıf: `vhero / hero`

## İçerik / veri
- Eyebrow: SAKARYA · SİNEMATİK VİDEO PRODÜKSİYON
- H1: Sakarya Video Çekimi ve Prodüksiyon
- Güven rozeti: 13+ marka · 26+ içerik
- CTA: Ücretsiz Ön Görüşme (birincil) + Projelerimizi İzleyin

## Tasarım & motion
Koyu set arka planı, video/still. **LCP burada** → eager + preload, lazy DEĞİL.

## Bilinen sorunlar / backlog
- [ ] LCP görseli eager+preload doğrula
- [ ] Rozet sayıları güncel mi (13+/26+/32 tutarlılığı)

## "Bitti" kontrolleri
- [ ] a11y  [ ] mobil  [ ] reduced-motion  [ ] CLS

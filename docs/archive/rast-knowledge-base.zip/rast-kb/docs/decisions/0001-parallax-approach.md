# ADR 0001 — Showreel parallax/pin yaklaşımı

- Durum: Öneri (tartışmaya açık)
- Bağlam: Mevcut pin JS class state machine; programatik scroll'da takılabiliyor,
  `transition: all` + transition tabanlı yumuşatma hızlı scroll'da lastik hissi veriyor.
- Karar (öneri): Pin'i CSS `position: sticky` ile yap; JS yalnız 0..1 ilerleme hesaplasın
  (tek rAF + küçük lerp). Animasyon yalnız `transform`/`opacity`, `will-change` yönetimli.
- Sonuçlar: Daha sağlam state, daha akıcı; refactor eforu orta. Alternatif: GSAP ScrollTrigger
  (güçlü ama bağımlılık + bütçe). Önce vanilla iyileştir, gerekirse GSAP'e geç.

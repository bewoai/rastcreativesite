# Rast Creative Studio — Knowledge Base

Bu klasör, Claude Code ve Codex'in projeyi 10x hızlı geliştirmesi için bağlam iskeletidir.
Repo kök dizinine (`rastcreativesite`) yerleştir. `CLAUDE.md` kökte kalmalı.

## Nasıl kullanılır
- Claude Code aç → `CLAUDE.md` otomatik okunur.
- Bir işe başlarken: ilgili `docs/sections/<bölüm>.md` + gereken `docs/context/*` dosyasını oku.
- İş bitince ilgili section dosyasını güncelle (yaşayan dokümantasyon).

## Harita
- `docs/00-master-plan.md` — yol haritası & backlog
- `docs/context/` — business, brand-voice, design-system, tech-stack, seo, content, motion-parallax
- `docs/sections/` — her sahne için bağlam (showreel = ⭐ odak)
- `docs/playbooks/` — tekrarlanan işler
- `docs/decisions/` — ADR
- `.claude/commands/` — slash komutları
- `automations/` — tooling & ffmpeg reçetesi

## Önce doldurulacak boşluklar (___ işaretli)
- tech-stack: klasör yapısı, build/deploy komutları
- design-system: gerçek token tablosu (koddan)

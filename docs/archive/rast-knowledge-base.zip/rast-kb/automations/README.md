# Otomasyonlar & 10x Tooling

## Hızlı kazançlar (kur-bırak)
1. **Image pipeline** — Astro `<Image/>` (sharp) ile webp/avif + boyut otomatik.
   Eksik alt'ları yakalayan lint (aşağıda).
2. **Lighthouse CI** — her PR'da prod build'e karşı LCP/CLS/SEO bütçesi.
3. **Sitemap + robots** — @astrojs/sitemap, otomatik.
4. **Showreel transcode** — `transcode-showreel.md` reçetesi (ffmpeg).
5. **a11y/SEO lint** — alt-eksik ve boyutsuz görsel için CI guard.
6. **Pre-commit** — prettier + astro check.

## Önerilen GitHub Actions (taslak)
- build + astro check
- lighthouse-ci (treosh/lighthouse-ci-action)
- broken-link + alt-text guard

## transcode-showreel.md
Bkz. ayrı dosya: web için muted/loop mp4+webm + poster üretimi.

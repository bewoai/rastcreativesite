# Showreel transcode reçetesi (ffmpeg)

# 1) 20-30 sn kurguyu web'e uygun, sessiz, kompakt mp4:
ffmpeg -i reel-master.mov -an -vf "scale=-2:720" -c:v libx264 -crf 23 -preset slow -movflags +faststart reel-720.mp4
# 2) webm alternatifi:
ffmpeg -i reel-master.mov -an -vf "scale=-2:720" -c:v libvpx-vp9 -crf 33 -b:v 0 reel-720.webm
# 3) poster (ilk net kare):
ffmpeg -i reel-720.mp4 -vf "select=eq(n\,30)" -frames:v 1 reel-poster.jpg

# Kullanım (pano içinde):
# <video muted loop playsinline autoplay preload="metadata" poster="reel-poster.jpg">
#   <source src="reel-720.webm" type="video/webm">
#   <source src="reel-720.mp4" type="video/mp4">
# </video>
# Not: mobilde autoplay için muted+playsinline şart. Ağır ise poster+tıkla-oynat.
